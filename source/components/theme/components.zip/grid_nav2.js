import { h, Component } from 'preact'
import style from './grid_nav.less'

export default ( data ) => {
  return (
      <Cell class={ style.grid_nav2 }>  
  <h3 class={ style.next }>Get In Touch Today To Discuss Your Project</h3>
      </Cell>  
  )
}
